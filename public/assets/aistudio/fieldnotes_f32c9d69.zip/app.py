import streamlit as st

from portfolio.ui import render_portfolio


st.set_page_config(
    page_title="Jordan Ellis — Technology, Risk & Change (Demo)",
    layout="centered",
    initial_sidebar_state="collapsed",
    menu_items={
        "About": "A fictional consultant portfolio demo. Sample data is illustrative only."
    },
)

render_portfolio()
