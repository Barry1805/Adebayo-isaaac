import {
  ArrowDownRight,
  ArrowRight,
  ArrowUpRight,
  CalendarDays,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock3,
  Moon,
  Sun,
  X,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import type { FormEvent } from "react";
import { useTheme } from "../contexts/ThemeContext";

const capabilities = [
  {
    number: "01",
    title: "Atlassian & collaboration platforms",
    description:
      "Platform strategy, architecture, governance and delivery across Atlassian and the wider digital workplace.",
  },
  {
    number: "02",
    title: "Security, risk & audit readiness",
    description:
      "Practical access controls, permission reviews and evidence that make governance part of day-to-day work.",
  },
  {
    number: "03",
    title: "Operating models & change",
    description:
      "Clear ownership, service workflows and adoption plans that help people make new ways of working stick.",
  },
];

const story = [
  {
    number: "01",
    title: "Context",
    description:
      "A fictional, mid-sized financial group had grown through several reorganisations. Its Atlassian workspace, identity directory and service tools had different access rules, unclear owners and a backlog of manual approvals.",
  },
  {
    number: "02",
    title: "Intervention",
    description:
      "I mapped access paths across the connected tools, agreed role-based permissions with system owners, and piloted a simpler request and review process with three teams. The handover included a control map and a repeatable review playbook.",
  },
  {
    number: "03",
    title: "Outcome",
    description:
      "In this illustrative scenario, recurring access exceptions fell by 38%, median approval time moved from 14 days to 5, and every critical admin group had a named owner. These are invented demo figures, not verified client results.",
  },
];

const demoMetrics = [
  { value: "−38%", label: "repeat access exceptions" },
  { value: "14 → 5 days", label: "median approval time" },
  { value: "100%", label: "critical groups with an owner" },
];

const callTimes = ["09:30", "11:00", "14:00", "15:30"];
const callLength = "25 minutes";

function BrandMark() {
  return (
    <svg aria-hidden="true" className="brand-mark" fill="none" viewBox="0 0 36 36">
      <path d="M7 13V7h6M23 7h6v6M29 23v6h-6M13 29H7v-6" />
      <path d="M12 18h12M18 12v12" />
      <circle cx="18" cy="18" r="3.5" />
    </svg>
  );
}

function localDateKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function getDateBounds() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const firstDate = new Date(today);
  firstDate.setDate(firstDate.getDate() + 1);
  const lastDate = new Date(today);
  lastDate.setDate(lastDate.getDate() + 42);
  return { firstDate, lastDate };
}

function isSampleAvailable(date: Date) {
  const { firstDate, lastDate } = getDateBounds();
  const weekday = date.getDay();
  return date >= firstDate && date <= lastDate && weekday !== 0 && weekday !== 6;
}

function findNextSampleDay() {
  const { firstDate } = getDateBounds();
  for (let offset = 0; offset <= 6; offset += 1) {
    const candidate = new Date(firstDate);
    candidate.setDate(candidate.getDate() + offset);
    if (isSampleAvailable(candidate)) return candidate;
  }
  return firstDate;
}

function monthCells(month: Date) {
  const year = month.getFullYear();
  const monthIndex = month.getMonth();
  const daysInMonth = new Date(year, monthIndex + 1, 0).getDate();
  const mondayFirstOffset = (new Date(year, monthIndex, 1).getDay() + 6) % 7;
  return [
    ...Array.from({ length: mondayFirstOffset }, () => null),
    ...Array.from({ length: daysInMonth }, (_, index) => new Date(year, monthIndex, index + 1)),
  ];
}

function DiscoveryCalendar({ onClose }: { onClose: () => void }) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const [step, setStep] = useState<"questions" | "calendar">("questions");
  const [answers, setAnswers] = useState({ name: "", email: "", organisation: "", focus: "", context: "" });
  const [visibleMonth, setVisibleMonth] = useState(() => {
    const now = new Date();
    return new Date(now.getFullYear(), now.getMonth(), 1);
  });
  const [selectedDate, setSelectedDate] = useState<Date | null>(() => findNextSampleDay());
  const [selectedTime, setSelectedTime] = useState("");
  const [confirmed, setConfirmed] = useState(false);
  const calendarCells = useMemo(() => monthCells(visibleMonth), [visibleMonth]);
  const monthName = new Intl.DateTimeFormat("en-GB", {
    month: "long",
    year: "numeric",
  }).format(visibleMonth);
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || "your local time";
  const { lastDate } = getDateBounds();
  const nextMonth = new Date(visibleMonth.getFullYear(), visibleMonth.getMonth() + 1, 1);
  const currentMonth = new Date(new Date().getFullYear(), new Date().getMonth(), 1);
  const canGoBack = visibleMonth > currentMonth;
  const canGoForward = nextMonth <= new Date(lastDate.getFullYear(), lastDate.getMonth(), 1);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (!dialog) return;
    if (!dialog.open) dialog.showModal();
    return () => {
      if (dialog.open) dialog.close();
    };
  }, []);

  function changeMonth(offset: number) {
    setVisibleMonth((month) => new Date(month.getFullYear(), month.getMonth() + offset, 1));
  }

  function chooseDate(date: Date) {
    setSelectedDate(date);
    setSelectedTime("");
    setConfirmed(false);
  }

  function submitIntake(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setAnswers({
      name: String(form.get("name") ?? ""),
      email: String(form.get("email") ?? ""),
      organisation: String(form.get("organisation") ?? ""),
      focus: String(form.get("focus") ?? ""),
      context: String(form.get("context") ?? ""),
    });
    setStep("calendar");
  }

  const selectedDateLabel = selectedDate
    ? new Intl.DateTimeFormat("en-GB", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric",
      }).format(selectedDate)
    : "Choose an available day";

  return (
    <dialog
      aria-describedby="scheduler-description"
      aria-labelledby="scheduler-title"
      className="scheduler-dialog"
      onCancel={(event) => {
        event.preventDefault();
        onClose();
      }}
      onClick={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      ref={dialogRef}
    >
      <div className="scheduler-content">
        <header className="scheduler-header">
          <div className="scheduler-title-wrap">
            <span className="scheduler-icon"><CalendarDays aria-hidden="true" size={18} /></span>
            <div>
              <p className="scheduler-eyebrow">COMPLIMENTARY INTRODUCTION</p>
              <h2 id="scheduler-title">Book a discovery call</h2>
            </div>
          </div>
          <button aria-label="Close booking calendar" autoFocus className="icon-button" onClick={onClose} type="button">
            <X aria-hidden="true" size={19} />
          </button>
        </header>

        <p className="scheduler-description" id="scheduler-description">
          A focused first conversation about your challenge, your goals and whether the fit is right. No preparation needed.
        </p>

        <div className="scheduler-meta">
          <span><Clock3 aria-hidden="true" size={14} /> {callLength}</span>
          <span>{timeZone}</span>
          <span className="sample-label">DEMO FLOW</span>
        </div>

        <div aria-label="Booking steps" className="scheduler-steps">
          <span className={step === "questions" ? "is-current" : "is-complete"}><b>1</b> A little context</span>
          <span className={step === "calendar" ? "is-current" : ""}><b>2</b> Choose a time</span>
        </div>

        {step === "questions" ? (
          <form className="intake-form" onSubmit={submitIntake}>
            <div className="intake-heading">
              <p className="scheduler-eyebrow">BEFORE WE MEET</p>
              <h3>A little about what brings you here.</h3>
              <p>A few details help make the first conversation useful. This is a demo form and nothing you enter is sent or saved.</p>
            </div>
            <div className="booking-fields">
              <label>Name <input autoComplete="name" name="name" placeholder="Taylor Morgan" required /></label>
              <label>Email <input autoComplete="email" name="email" placeholder="you@example.com" required type="email" /></label>
              <label>Organisation <input autoComplete="organization" name="organisation" placeholder="Company or team" /></label>
              <label>What would you like to discuss?
                <select defaultValue="" name="focus" required>
                  <option disabled value="">Choose a topic</option>
                  <option>Atlassian or collaboration platforms</option>
                  <option>Security, risk or audit readiness</option>
                  <option>Operating model or service workflows</option>
                  <option>Something else</option>
                </select>
              </label>
              <label className="intake-context">What is the main challenge you are trying to solve?
                <textarea maxLength={600} name="context" placeholder="A sentence or two is plenty." rows={3} />
              </label>
            </div>
            <div className="intake-actions">
              <span className="small-mono">DEMO ONLY · NOT TRANSMITTED</span>
              <button className="booking-submit" type="submit">Continue to times <ArrowRight aria-hidden="true" size={16} /></button>
            </div>
          </form>
        ) : confirmed ? (
          <div aria-live="polite" className="booking-confirmation" role="status">
            <CheckCircle2 aria-hidden="true" size={33} />
            <h3>Demo slot selected</h3>
            <p>{selectedDateLabel} at {selectedTime} ({timeZone})</p>
            <p className="booking-disclaimer">Thanks, {answers.name}. This is a website demo. No appointment was reserved, no email was sent, and the sample availability is not connected to a real calendar.</p>
            <button className="text-link" onClick={() => { setConfirmed(false); setStep("calendar"); }} type="button">Choose another sample time</button>
          </div>
        ) : (
          <>
            <button className="scheduler-back" onClick={() => setStep("questions")} type="button"><ChevronLeft aria-hidden="true" size={15} /> Edit your details</button>
            <div className="calendar-heading">
              <button aria-label="Show previous month" className="icon-button calendar-nav" disabled={!canGoBack} onClick={() => changeMonth(-1)} type="button">
                <ChevronLeft aria-hidden="true" size={17} />
              </button>
              <h3>{monthName}</h3>
              <button aria-label="Show next month" className="icon-button calendar-nav" disabled={!canGoForward} onClick={() => changeMonth(1)} type="button">
                <ChevronRight aria-hidden="true" size={17} />
              </button>
            </div>

            <div aria-label="Choose a day" className="calendar-grid">
              {["M", "T", "W", "T", "F", "S", "S"].map((day, index) => (
                <span aria-hidden="true" className="calendar-weekday" key={`${day}-${index}`}>{day}</span>
              ))}
              {calendarCells.map((date, index) => {
                if (!date) return <span aria-hidden="true" className="calendar-empty" key={`empty-${index}`} />;
                const selected = selectedDate !== null && localDateKey(date) === localDateKey(selectedDate);
                const available = isSampleAvailable(date);
                return (
                  <button
                    aria-label={new Intl.DateTimeFormat("en-GB", { weekday: "long", day: "numeric", month: "long" }).format(date)}
                    aria-pressed={selected}
                    className={`calendar-day${selected ? " is-selected" : ""}${available ? " is-available" : ""}`}
                    disabled={!available}
                    key={localDateKey(date)}
                    onClick={() => chooseDate(date)}
                    type="button"
                  >
                    {date.getDate()}
                  </button>
                );
              })}
            </div>

            <div className="time-section">
              <div className="time-section-heading">
                <div>
                  <p className="scheduler-eyebrow">SELECT A TIME</p>
                  <h3>{selectedDateLabel}</h3>
                </div>
                <span className="small-mono">{timeZone}</span>
              </div>
              <div className="time-options">
                {callTimes.map((time) => (
                  <button
                    aria-pressed={selectedTime === time}
                    className={`time-option${selectedTime === time ? " is-selected" : ""}`}
                    key={time}
                    onClick={() => { setSelectedTime(time); setConfirmed(false); }}
                    type="button"
                  >
                    {time}
                  </button>
                ))}
              </div>
            </div>

            {selectedTime && <div className="booking-form"><div className="booking-form-heading"><span className="scheduler-eyebrow">READY TO CONFIRM?</span><span className="small-mono">{answers.name} · {answers.focus}</span></div><button className="booking-submit" onClick={() => setConfirmed(true)} type="button">Confirm sample slot <ArrowRight aria-hidden="true" size={16} /></button></div>}
          </>
        )}

        <p className="scheduler-footnote">Sample dates and times are for demonstration only. Questionnaire answers remain in this browser session only. Connect Calendly, Cal.com or your calendar before accepting real bookings.</p>
      </div>
    </dialog>
  );
}

export default function Home() {
  const { theme, toggleTheme } = useTheme();
  const [calendarOpen, setCalendarOpen] = useState(false);

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main-content">Skip to content</a>

      <header className="site-header">
        <a aria-label="Back to the top of the page" className="brand" href="#top">
          <BrandMark />
          <span className="brand-copy">
            <span className="brand-name">Jordan Ellis</span>
            <span className="brand-descriptor">TECHNOLOGY, RISK & CHANGE · DEMO</span>
          </span>
        </a>
        <nav aria-label="Main navigation" className="main-nav">
          <a href="#work">Selected work</a>
          <a href="#capabilities">Capabilities</a>
          <a className="nav-contact" href="#contact">Contact <ArrowUpRight aria-hidden="true" size={15} strokeWidth={1.7} /></a>
          <button
            aria-label={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
            aria-pressed={theme === "dark"}
            className="theme-toggle"
            onClick={() => toggleTheme?.()}
            title={`Switch to ${theme === "dark" ? "light" : "dark"} mode`}
            type="button"
          >
            {theme === "dark" ? <Sun aria-hidden="true" size={15} /> : <Moon aria-hidden="true" size={15} />}
            <span>{theme === "dark" ? "Light" : "Dark"}</span>
          </button>
        </nav>
      </header>

      <main id="main-content">
        <section aria-labelledby="hero-title" className="hero section-wrap" id="top">
          <div className="section-topline">
            <p className="eyebrow"><span className="live-dot" /> FICTIONAL DEMO PROFILE <span className="eyebrow-divider">/</span> FINANCIAL SERVICES</p>
            <p className="small-mono">INDEPENDENT PRACTICE <span>—</span> 001</p>
          </div>

          <div className="hero-grid">
            <div className="hero-copy">
              <p className="hero-pretitle">Platforms are part of the story. Better ways of working are the point.</p>
              <h1 id="hero-title">Make complex platforms easier to <span className="hero-result">trust, govern and use.</span></h1>
              <p className="hero-description">
                I help growing and regulated organisations connect <span>platform strategy</span>, <span>security controls</span> and <span>operational change</span>—so technology supports the way people need to work.
              </p>
              <div className="hero-actions">
                <a className="text-link hero-link" href="#work">Explore the case study <ArrowDownRight aria-hidden="true" size={17} strokeWidth={1.7} /></a>
                <span className="demo-inline">All names, figures and project details below are fictional demo data.</span>
              </div>
            </div>

            <aside aria-label="Practice overview" className="practice-panel">
              <div className="panel-heading">
                <span className="panel-mark"><BrandMark /></span>
                <span className="small-mono">PRACTICE / OVERVIEW</span>
              </div>
              <p className="panel-intro">One connected view<br />of the work.</p>
              <div className="panel-list">
                <div><span className="panel-count">01</span><span>Platform strategy</span><span className="panel-line" /></div>
                <div><span className="panel-count">02</span><span>Security & governance</span><span className="panel-line" /></div>
                <div><span className="panel-count">03</span><span>Operating model</span><span className="panel-line" /></div>
              </div>
              <p className="panel-note">Across Atlassian and the wider digital workplace—not tied to one platform.</p>
              <div aria-hidden="true" className="panel-coordinate">DEMO / UK</div>
            </aside>
          </div>

          <div className="hero-bottomline">
            <span className="small-mono">BASED IN LONDON, UK <i>·</i> WORKING WITH TEAMS WORLDWIDE</span>
            <a className="small-mono scroll-cue" href="#work">SCROLL TO EXPLORE <span aria-hidden="true">↓</span></a>
          </div>
        </section>

        <section aria-labelledby="work-title" className="case-study section-wrap" id="work">
          <div className="section-heading">
            <span className="section-index">01 <span>/</span> DEMO CASE STUDY</span>
            <span className="section-context">FICTIONAL CLIENT · ILLUSTRATIVE RESULTS</span>
          </div>

          <div className="case-title-grid">
            <h2 id="work-title">From scattered access to an audit-ready operating model.</h2>
            <p className="case-summary">A fictional financial services group needed its Atlassian environment and adjacent work systems to follow one clear, accountable set of rules.</p>
          </div>

          <dl className="project-meta">
            <div><dt>Engagement</dt><dd>Platform, security & governance</dd></div>
            <div><dt>Organisation</dt><dd>Mid-sized financial group (fictional)</dd></div>
            <div><dt>Role</dt><dd>Independent transformation adviser</dd></div>
            <div><dt>Scope</dt><dd>Atlassian plus connected work systems</dd></div>
          </dl>

          <div aria-label="Illustrative demo outcomes" className="demo-metrics">
            {demoMetrics.map((metric) => (
              <div className="demo-metric" key={metric.label}>
                <strong>{metric.value}</strong>
                <span>{metric.label}</span>
              </div>
            ))}
          </div>

          <div className="story-list">
            {story.map((item) => (
              <article className="story-row" key={item.number}>
                <span aria-hidden="true" className="story-number">{item.number}</span>
                <h3>{item.title}</h3>
                <p>{item.description}</p>
              </article>
            ))}
          </div>

          <p className="case-footnote"><span aria-hidden="true">↳</span><span>DEMO SCENARIO ONLY. THE CLIENT, PROJECT DETAILS AND ALL OUTCOME FIGURES ARE INVENTED FOR THIS PREVIEW.</span></p>
        </section>

        <section aria-labelledby="capabilities-title" className="capabilities section-wrap" id="capabilities">
          <div className="section-heading">
            <span className="section-index">02 <span>/</span> HOW I CAN HELP</span>
            <span className="section-context">A PRACTICE WITH MORE THAN ONE LENS</span>
          </div>
          <div className="capabilities-intro">
            <h2 id="capabilities-title">Good systems work<br /><span>across boundaries.</span></h2>
            <p>From the platform itself to the controls and habits around it, the work is designed to fit your teams—not force every problem into one product.</p>
          </div>
          <div className="capability-list">
            {capabilities.map((capability) => (
              <article className="capability-row" key={capability.number}>
                <span className="capability-number">{capability.number}</span>
                <h3>{capability.title}</h3>
                <p>{capability.description}</p>
                <span aria-hidden="true" className="capability-arrow">↗</span>
              </article>
            ))}
          </div>
        </section>

        <section aria-labelledby="contact-title" className="contact section-wrap" id="contact">
          <div className="contact-topline">
            <span className="section-index">03 <span>/</span> A GOOD FIRST STEP</span>
            <span className="small-mono">25 MIN · NO PREPARATION NEEDED</span>
          </div>
          <div className="contact-body">
            <div>
              <p className="contact-kicker">Complimentary discovery call · demo booking flow</p>
              <h2 id="contact-title">Let’s untangle<br /><span>what’s next.</span></h2>
            </div>
            <div className="contact-aside">
              <p>Bring the platform, process or control issue that’s slowing things down. We’ll clarify the challenge, find the right first move and see whether working together makes sense.</p>
              <button className="contact-button" onClick={() => setCalendarOpen(true)} type="button">
                Book a discovery call <CalendarDays aria-hidden="true" size={17} strokeWidth={1.7} />
              </button>
              <p className="contact-demo-note">Demo calendar only · sample times, no real invite is sent.</p>
            </div>
          </div>
          <div className="contact-details" id="contact-details">
            <span className="small-mono">DEMO CONTACT</span>
            <a className="contact-placeholder" href="mailto:hello@jordanellis.example">hello@jordanellis.example</a>
            <span className="small-mono">LONDON, UK · UK TIME</span>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <a aria-label="Back to the top" className="footer-brand" href="#top"><BrandMark /><span>Jordan Ellis</span></a>
        <p>Independent by design. Collaborative by nature. <span>Fictional demo profile.</span></p>
        <span className="small-mono">© {new Date().getFullYear()} · SAMPLE CONTENT</span>
      </footer>

      {calendarOpen && <DiscoveryCalendar onClose={() => setCalendarOpen(false)} />}
    </div>
  );
}
