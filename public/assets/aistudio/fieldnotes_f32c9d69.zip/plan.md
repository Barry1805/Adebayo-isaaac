# Streamlit migration plan

## Direction and constraints

Replace the active static React experience with a Python-authored Streamlit application. Use Streamlit's Python layout, text, form and input APIs only. Do not hand-write HTML, CSS, or JavaScript. The framework will render its own browser interface. Preserve the fictional demo profile, compact case-story order, broader-than-Atlassian capabilities, and pre-call questions followed by sample booking; accept that Streamlit's native appearance cannot exactly reproduce the custom reference styling.

## Product and interaction design

Use a restrained editorial hierarchy in Streamlit-native containers and columns: slim text-led navigation, concise profile heading, project metadata, Context / Intervention / Outcome, three capability areas, then the discovery-call invitation. The reference informs hierarchy and brevity, not its brand assets or copy. Use Streamlit's Settings / Theme control for light or dark mode; a custom in-page mode switch would require styling outside the user's Python-only constraint. Use Streamlit's own built-in appearance and controls rather than custom color tokens or DOM manipulation.

The questionnaire asks for required name, email and topic, plus optional organisation and a challenge description capped at 600 characters. Submitted answers are handled only in the active Streamlit session; do not persist them to a database or file, log them, email them, or claim they remain exclusively on the visitor's device. Explain that answers reach the app server for processing. The sample date picker covers the next 42 days, rejects weekends, and is followed by slots at 09:30, 11:00, 14:00 and 15:30 for a 25-minute call. Because Python-only Streamlit cannot automatically read a visitor's browser timezone, provide an explicit timezone selector with Europe/London as the demo default and common alternatives. Confirmation must say that no appointment was reserved and no email was sent.

## Structure and serving

- `app.py`: Streamlit entrypoint and page-level composition.
- `portfolio/content.py`: fictional profile, case narrative, sample metrics and capabilities.
- `portfolio/ui.py`: native Streamlit sections, navigation and booking interaction.
- `requirements.txt`: pinned Streamlit dependency.
- `Dockerfile`: production image and Streamlit entrypoint bound to `0.0.0.0`, honoring `PORT`.
- `README.md`: Python setup/run instructions and note that the retained `client/` source tree is legacy, not the active app.
- `client/public/manus-routes.json`: preserve the single-page `/` route declaration.

Enable the already-approved managed Server capability; keep the managed database disabled and do not publish this project during migration.
