# Personal Consulting Portfolio — Streamlit

The active website is a Python Streamlit app. Its visible copy and interactions are authored in Python with Streamlit APIs; this project does not hand-write HTML, CSS, or JavaScript for the active app. Streamlit generates its own browser interface. The old React source remains under `client/` as a legacy fallback and is not the active site.

## Run locally

```bash
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
export PORT=3000
streamlit run app.py --server.address 0.0.0.0 --server.port "$PORT"
```

Python 3.12 and the pinned Streamlit dependency are used by the container runtime. The root `Dockerfile` starts Streamlit on `0.0.0.0` and honors the platform-provided `PORT`; the health endpoint is `/healthz`.

## Demo behavior

The identity, client and outcome figures are fictional. The discovery flow asks a few questions, then shows sample dates and times; there is no connected calendar, reservation, or email sender. Submitted answers are processed by the Streamlit app in the current session and are not persisted to a database or file. Avoid entering sensitive information. Choose a time zone explicitly; Python-only Streamlit cannot read the visitor's browser zone without client-side code. Light/dark appearance is available from Streamlit's built-in Settings / Theme control.

The application does not require a database. `client/public/manus-routes.json` remains the single-page route declaration from the original project. The project is not automatically published when code is checkpointed.
