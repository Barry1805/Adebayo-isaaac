# TODO

- [x] Present a fictional consultant identity, broader-than-Atlassian positioning, case study, illustrative metrics, and three capability areas in the previous version.
- [x] Keep the project's inspiration notes in `research/consulting-site-inspiration.md`.
- [ ] Make the active website a Streamlit application authored with Python APIs only: do not hand-write HTML, CSS, or JavaScript.
- [ ] Preserve the fictional demo profile, fictional client, clearly illustrative metrics, broader-than-Atlassian positioning, and Context / Intervention / Outcome story.
- [ ] Build the page with native Streamlit layout, containers, columns, text and inputs. Keep the reference's concise case-study hierarchy without claiming a pixel-perfect reproduction.
- [ ] Support light and dark appearance through Streamlit's built-in Settings / Theme control; do not add a custom CSS-based theme button.
- [ ] “Book a discovery call” opens a two-step flow. Step 1 asks for required name and email; optional organisation; required topic chosen from Atlassian/collaboration platforms, security/risk/audit readiness, operating models/service workflows, or something else; and optional challenge text capped at 600 characters.
- [ ] Only after the questionnaire is submitted, step 2 presents a native date picker for the next 42 days, rejects weekend dates, lets the visitor select a timezone (Europe/London by default), offers 09:30, 11:00, 14:00 and 15:30, and identifies the call as 25 minutes.
- [ ] The confirmation must explicitly say the slot is only a demo, no appointment was reserved, and no email was sent; sample availability is not connected to a real calendar.
- [ ] Explain before the form is submitted that answers are sent to the Streamlit app for processing, kept only in the active session, and not written to a database or file, logged, emailed, or otherwise persisted by the app.
- [ ] Provide pinned Python dependencies and clear Python run instructions. The Streamlit container listens on `0.0.0.0` and honors `PORT`; managed database stays disabled, and this migration is not published.
