import streamlit as st

from portfolio.booking import render_booking_dialog
from portfolio.content import CAPABILITIES, CASE_STUDY, PROFILE


def _render_navigation() -> None:
    brand, work, capabilities, contact = st.columns([2.1, 0.9, 1.0, 1.0])
    with brand:
        st.markdown(f"**{PROFILE['name']}**  \n{PROFILE['descriptor']}")
    with work:
        st.markdown("[Selected work](#selected-work)")
    with capabilities:
        st.markdown("[Capabilities](#capabilities)")
    with contact:
        st.markdown("[Discovery call](#discovery-call)")
    st.divider()


def _render_hero() -> None:
    left, right = st.columns([3, 1])
    with left:
        st.caption(f"FICTIONAL DEMO PROFILE  /  {PROFILE['industry']}")
    with right:
        st.caption(PROFILE["practice_number"])

    st.write(f"*{PROFILE['tagline']}*")
    st.title(PROFILE["headline"])
    st.write(PROFILE["summary"])
    st.caption(PROFILE["demo_notice"])
    st.caption(PROFILE["location"])
    st.markdown("[Explore the case study ↓](#selected-work)")
    st.divider()


def _render_case_study() -> None:
    st.header("01 / Demo case study", anchor="selected-work")
    st.caption("FICTIONAL CLIENT · ILLUSTRATIVE RESULTS")
    st.subheader(CASE_STUDY["title"])
    st.write(CASE_STUDY["summary"])

    metadata_columns = st.columns(4)
    for column, (label, value) in zip(metadata_columns, CASE_STUDY["metadata"]):
        with column:
            st.caption(label.upper())
            st.write(value)

    st.divider()
    metric_columns = st.columns(3)
    for column, (value, label) in zip(metric_columns, CASE_STUDY["metrics"]):
        with column:
            st.metric(label, value)

    for heading, description in CASE_STUDY["story"]:
        with st.container(border=True):
            st.subheader(heading)
            st.write(description)

    st.caption(CASE_STUDY["disclaimer"])


def _render_capabilities() -> None:
    st.header("02 / How I can help", anchor="capabilities")
    st.caption("A practice with more than one lens")
    st.subheader("Good systems work across boundaries.")
    st.write(
        "From the platform itself to the controls and habits around it, the work is designed "
        "to fit your teams—not force every problem into one product."
    )

    columns = st.columns(len(CAPABILITIES))
    for number, (column, (title, description)) in enumerate(
        zip(columns, CAPABILITIES), start=1
    ):
        with column:
            with st.container(border=True):
                st.caption(f"{number:02d}")
                st.subheader(title)
                st.write(description)


def _render_contact() -> None:
    st.header("03 / A good first step", anchor="discovery-call")
    st.caption("25 minutes · no preparation needed · demo booking flow")
    left, right = st.columns([1.2, 1])
    with left:
        st.subheader("Let’s untangle what’s next.")
        st.write("Bring the platform, process, or control issue that’s slowing things down.")
    with right:
        st.write(
            "We’ll clarify the challenge, find a useful first move, and see whether working "
            "together makes sense."
        )
        if st.button("Book a discovery call", type="primary", width="stretch"):
            st.session_state["booking_open"] = True
            st.session_state["booking_step"] = "questions"
            st.session_state.pop("booking_answers", None)
            for key in (
                "call_name",
                "call_email",
                "call_organisation",
                "call_topic",
                "call_challenge",
                "call_date",
                "call_timezone",
                "call_time",
                "booking_confirmation",
            ):
                st.session_state.pop(key, None)
            st.rerun()

    st.caption("Demo calendar only · no real booking or email is created.")
    st.divider()
    st.caption(f"DEMO CONTACT  ·  {PROFILE['contact']}  ·  LONDON, UK")


def render_portfolio() -> None:
    _render_navigation()
    _render_hero()
    _render_case_study()
    st.divider()
    _render_capabilities()
    st.divider()
    _render_contact()
    st.caption("Independent by design. Collaborative by nature. Fictional demo profile.")
    st.caption("SAMPLE CONTENT · DEMO PROFILE")
    render_booking_dialog()
