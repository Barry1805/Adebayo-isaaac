from datetime import date, datetime, timedelta
import re
from zoneinfo import ZoneInfo

import streamlit as st

from portfolio.content import DISCUSSION_TOPICS

CALL_TIMES = ["09:30", "11:00", "14:00", "15:30"]
TIME_ZONES = {
    "UK — London (Europe/London)": "Europe/London",
    "UTC": "UTC",
    "US — Eastern (America/New_York)": "America/New_York",
    "US — Central (America/Chicago)": "America/Chicago",
    "US — Pacific (America/Los_Angeles)": "America/Los_Angeles",
    "Europe — Paris (Europe/Paris)": "Europe/Paris",
    "Singapore (Asia/Singapore)": "Asia/Singapore",
}
EMAIL_PATTERN = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
FORM_KEYS = (
    "call_name",
    "call_email",
    "call_organisation",
    "call_topic",
    "call_challenge",
)


def _close_dialog() -> None:
    st.session_state["booking_open"] = False
    st.session_state["booking_step"] = "questions"
    st.session_state.pop("booking_answers", None)
    st.session_state.pop("booking_confirmation", None)
    st.rerun()


def _render_questions() -> None:
    st.caption("STEP 1 OF 2 · BEFORE WE MEET")
    st.subheader("A little about what brings you here.")
    st.write("A few details help make the first conversation useful.")
    st.info(
        "This demo processes submitted answers in the Streamlit app session. They are not "
        "written to a database or file, logged, or emailed. Please do not enter sensitive information."
    )

    with st.form("discovery_questions"):
        left, right = st.columns(2)
        with left:
            name = st.text_input("Name (required)", key="call_name")
            organisation = st.text_input("Organisation (optional)", key="call_organisation")
        with right:
            email = st.text_input("Email (required)", key="call_email")
            topic = st.selectbox(
                "What would you like to discuss? (required)",
                options=DISCUSSION_TOPICS,
                index=None,
                placeholder="Choose a topic",
                key="call_topic",
            )
        challenge = st.text_area(
            "What is the main challenge you are trying to solve? (optional)",
            max_chars=600,
            placeholder="A sentence or two is plenty.",
            key="call_challenge",
        )
        submitted = st.form_submit_button(
            "Continue to times",
            type="primary",
            width="stretch",
        )

    if submitted:
        if not name.strip():
            st.error("Please enter your name.")
            return
        if not EMAIL_PATTERN.fullmatch(email.strip()):
            st.error("Please enter a valid email address.")
            return
        if topic is None:
            st.error("Please choose a discussion topic.")
            return

        st.session_state["booking_answers"] = {
            "name": name.strip(),
            "email": email.strip(),
            "organisation": organisation.strip(),
            "topic": topic,
            "challenge": challenge.strip(),
        }
        st.session_state["booking_step"] = "calendar"
        st.rerun()


def _render_calendar() -> None:
    answers = st.session_state.get("booking_answers", {})
    if not answers:
        st.session_state["booking_step"] = "questions"
        st.rerun()

    st.caption("STEP 2 OF 2 · CHOOSE A SAMPLE TIME")
    st.write(f"Topic: **{answers['topic']}**")
    st.write("25-minute discovery call · illustrative availability")

    timezone_label = st.selectbox(
        "Time zone",
        options=list(TIME_ZONES),
        index=0,
        key="call_timezone",
    )
    zone_name = TIME_ZONES[timezone_label]
    today = datetime.now(ZoneInfo(zone_name)).date()
    first_day = today + timedelta(days=1)
    last_day = today + timedelta(days=42)

    saved_date = st.session_state.get("call_date")
    if not isinstance(saved_date, date) or not first_day <= saved_date <= last_day:
        st.session_state["call_date"] = first_day

    selected_date = st.date_input(
        "Choose a date",
        min_value=first_day,
        max_value=last_day,
        key="call_date",
        format="DD/MM/YYYY",
    )
    st.caption(f"Times shown in {zone_name} · sample dates only")

    if selected_date.weekday() >= 5:
        st.warning("Sample appointments are available on weekdays only. Choose a Monday–Friday date.")
        return

    selected_time = st.selectbox("Available sample times", options=CALL_TIMES, key="call_time")
    st.caption("No sample appointment will be placed on a real calendar.")

    back, confirm = st.columns([1, 1])
    with back:
        if st.button("Back to questions", width="stretch"):
            st.session_state["booking_step"] = "questions"
            st.rerun()
    with confirm:
        if st.button("Confirm sample slot", type="primary", width="stretch"):
            st.session_state["booking_confirmation"] = {
                "date": selected_date.isoformat(),
                "time": selected_time,
                "timezone": zone_name,
            }
            st.session_state["booking_step"] = "confirmation"
            st.rerun()


def _render_confirmation() -> None:
    confirmation = st.session_state.get("booking_confirmation")
    if not confirmation:
        st.session_state["booking_step"] = "calendar"
        st.rerun()

    chosen_date = date.fromisoformat(confirmation["date"])
    formatted_date = chosen_date.strftime("%A, %d %B %Y")
    st.caption("DEMO CONFIRMATION")
    st.success("Sample slot selected")
    st.write(
        f"**{formatted_date} at {confirmation['time']} "
        f"({confirmation['timezone']}) · 25 minutes**"
    )
    st.info(
        "No appointment was reserved and no email was sent. These sample times are not "
        "connected to a real calendar."
    )
    if st.button("Close", type="primary", width="stretch"):
        _close_dialog()


@st.dialog("Book a discovery call", width="large", dismissible=False)
def _booking_dialog() -> None:
    close_column, _ = st.columns([1, 4])
    with close_column:
        if st.button("Close", key="close_booking_dialog"):
            _close_dialog()

    step = st.session_state.get("booking_step", "questions")
    if step == "questions":
        _render_questions()
    elif step == "calendar":
        _render_calendar()
    else:
        _render_confirmation()


def render_booking_dialog() -> None:
    if st.session_state.get("booking_open", False):
        _booking_dialog()
