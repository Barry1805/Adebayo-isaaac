PROFILE = {
    "name": "Jordan Ellis",
    "descriptor": "TECHNOLOGY, RISK & CHANGE · DEMO",
    "industry": "FINANCIAL SERVICES",
    "practice_number": "INDEPENDENT PRACTICE — 001",
    "tagline": "Platforms are part of the story. Better ways of working are the point.",
    "headline": "Make complex platforms easier to trust, govern and use.",
    "summary": (
        "I help growing and regulated organisations connect platform strategy, "
        "security controls and operational change—so technology supports the way "
        "people need to work."
    ),
    "location": "BASED IN LONDON, UK · WORKING WITH TEAMS WORLDWIDE",
    "demo_notice": "All names, figures and project details below are fictional demo data.",
    "contact": "hello@jordanellis.example",
}

CASE_STUDY = {
    "title": "From scattered access to an audit-ready operating model.",
    "summary": (
        "A fictional financial services group needed its Atlassian environment "
        "and adjacent work systems to follow one clear, accountable set of rules."
    ),
    "metadata": [
        ("Engagement", "Platform, security & governance"),
        ("Organisation", "Mid-sized financial group (fictional)"),
        ("Role", "Independent transformation adviser"),
        ("Scope", "Atlassian plus connected work systems"),
    ],
    "metrics": [
        ("−38%", "Repeat access exceptions"),
        ("14 → 5 days", "Median approval time"),
        ("100%", "Critical groups with an owner"),
    ],
    "story": [
        (
            "01 / Context",
            "A fictional, mid-sized financial group had grown through several reorganisations. "
            "Its Atlassian workspace, identity directory and service tools had different access "
            "rules, unclear owners and a backlog of manual approvals.",
        ),
        (
            "02 / Intervention",
            "I mapped access paths across the connected tools, agreed role-based permissions "
            "with system owners, and piloted a simpler request and review process with three "
            "teams. The handover included a control map and a repeatable review playbook.",
        ),
        (
            "03 / Outcome",
            "In this illustrative scenario, recurring access exceptions fell by 38%, median "
            "approval time moved from 14 days to 5, and every critical admin group had a named "
            "owner. These are invented demo figures, not verified client results.",
        ),
    ],
    "disclaimer": (
        "Demo scenario only. The client, project details, and all outcome figures are "
        "invented for this preview."
    ),
}

CAPABILITIES = [
    (
        "Atlassian & collaboration platforms",
        "Platform strategy, architecture, governance and delivery across Atlassian and the "
        "wider digital workplace.",
    ),
    (
        "Security, risk & audit readiness",
        "Practical access controls, permission reviews and evidence that make governance part "
        "of day-to-day work.",
    ),
    (
        "Operating models & change",
        "Clear ownership, service workflows and adoption plans that help people make new ways "
        "of working stick.",
    ),
]

DISCUSSION_TOPICS = [
    "Atlassian or collaboration platforms",
    "Security, risk or audit readiness",
    "Operating models or service workflows",
    "Something else",
]
